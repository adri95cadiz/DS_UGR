package ejercicioBicicletas;

public class ManillarCarretera extends Manillar {
	
	public ManillarCarretera () {
		super(TC.CARRETERA);
	}

}
