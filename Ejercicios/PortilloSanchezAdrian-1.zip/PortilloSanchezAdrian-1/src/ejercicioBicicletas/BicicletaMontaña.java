package ejercicioBicicletas;

public class BicicletaMontaña extends Bicicleta {
	
	public BicicletaMontaña () {
		super(TC.MONTANA);
	}

}
