package ejercicioBicicletas;

public class BicicletaCarretera extends Bicicleta {	
	
	public BicicletaCarretera () {
		super(TC.CARRETERA);
	}

}
