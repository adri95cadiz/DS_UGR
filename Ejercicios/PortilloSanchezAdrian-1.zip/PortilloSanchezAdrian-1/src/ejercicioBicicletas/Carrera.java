package ejercicioBicicletas;
import java.util.ArrayList;

public interface Carrera {
	
	public ArrayList<Bicicleta> crearCarrera(int n);

}
