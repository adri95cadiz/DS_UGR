package ejercicioBicicletas;

public class ManillarMontaña extends Manillar {
	
	public ManillarMontaña () {
		super(TC.MONTANA);
	}

}
