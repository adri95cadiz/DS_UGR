package ejercicioBicicletas;

public enum TC {
	MONTANA,
	CARRETERA
}
