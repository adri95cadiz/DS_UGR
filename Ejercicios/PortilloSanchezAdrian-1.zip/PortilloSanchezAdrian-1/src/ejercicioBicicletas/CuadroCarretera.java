package ejercicioBicicletas;

public class CuadroCarretera extends Cuadro {
	
	public CuadroCarretera () {
		super(TC.CARRETERA);
	}

}
