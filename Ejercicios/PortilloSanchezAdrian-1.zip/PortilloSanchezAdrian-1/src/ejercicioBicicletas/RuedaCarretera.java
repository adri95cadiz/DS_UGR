package ejercicioBicicletas;

public class RuedaCarretera extends Rueda {
	
	public RuedaCarretera () {
		super(TC.CARRETERA);
	}

}
