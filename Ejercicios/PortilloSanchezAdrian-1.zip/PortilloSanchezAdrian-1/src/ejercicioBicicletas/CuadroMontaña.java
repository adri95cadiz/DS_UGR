package ejercicioBicicletas;

public class CuadroMontaña extends Cuadro {
	
	public CuadroMontaña () {
		super(TC.MONTANA);
	}

}
