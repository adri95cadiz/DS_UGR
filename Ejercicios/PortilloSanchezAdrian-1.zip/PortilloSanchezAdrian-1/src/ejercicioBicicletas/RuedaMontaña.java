package ejercicioBicicletas;

public class RuedaMontaña extends Rueda {
	
	public RuedaMontaña () {
		super(TC.MONTANA);
	}

}
