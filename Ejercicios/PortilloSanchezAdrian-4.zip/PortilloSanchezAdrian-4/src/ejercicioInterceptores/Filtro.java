package ejercicioInterceptores;

public interface Filtro {
	public double ejecutar(Object o);
}
