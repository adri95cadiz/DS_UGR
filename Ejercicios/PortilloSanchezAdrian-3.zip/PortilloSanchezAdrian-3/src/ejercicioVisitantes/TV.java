package ejercicioVisitantes;

public enum TV {
	regular, VIP, mayorista;
}
